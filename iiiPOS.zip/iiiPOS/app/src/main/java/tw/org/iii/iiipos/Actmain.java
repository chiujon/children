package tw.org.iii.iiipos;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Actmain extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actmain);
        Initial();
    }



    private View.OnClickListener btnbuy_click=new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            Intent intent = new Intent(Actmain.this,actorder.class);
            startActivity(intent);

        }
    };
    private void Initial() {

        btnbuy = findViewById(R.id.btnbuy);
        btnbuy.setOnClickListener(btnbuy_click);
    }

    Button btnbuy;
}
