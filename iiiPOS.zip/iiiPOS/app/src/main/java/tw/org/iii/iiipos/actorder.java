package tw.org.iii.iiipos;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class actorder extends Activity {

    int 杯數1 = 0, 杯數2 = 0, 杯數3 =0, 杯數4 = 0,總杯數=0;
    double 售價1 = 0.0, 售價2 = 0.0, 售價3 = 0.0, 售價4 = 0.0;
    double 品項1總價= 0.0,品項2總價 = 0.0,品項3總價 = 0.0,品項4總價 = 0.0 ;
    double 總價 = 0.0;


    private View.OnClickListener btn杯數1減_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數1 -=1;

            if(杯數1<0)
            {
                杯數1 = 0;
            }
            txt杯數1.setText(杯數1+"");
        }
    };

    private View.OnClickListener btn杯數1加_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數1 +=1 ;
            txt杯數1.setText(杯數1 + "");
        }
    };


     private TextWatcher txt杯數1_TextChanged = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            //int 杯數1=Integer.parseInt(txt杯數1.getText().toString());
            計算總價();
        }
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actorder);
        Initial();

    }


    private View.OnClickListener btn杯數2減_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數2 -= 1;
            if(杯數2<0)
            {
                杯數2 = 0;
            }
            txt杯數2.setText(杯數2+"");
        }
    };


    private View.OnClickListener btn杯數2加_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數2 += 1;
            txt杯數2.setText(杯數2 + "");

        }
    };

    private TextWatcher txt杯數2_TextChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            計算總價();
        }
    };
    private View.OnClickListener btn杯數3減_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數3 -= 1;
            if(杯數3<0)
            {
                杯數3 = 0;
            }
            txt杯數3.setText(杯數3+"");
        }
    };
    private View.OnClickListener btn杯數3加_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數3 += 1;
            txt杯數3.setText(杯數3+"");

        }
    };

    private TextWatcher txt杯數3_TextChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            計算總價();
        }
    };

    private View.OnClickListener btn杯數4減_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數4 -= 1;
            if(杯數4<0)
            {
                杯數4 = 0;
            }
            txt杯數4.setText(杯數4+"");
        }
    };
    private View.OnClickListener btn杯數4加_click = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            杯數4 += 1;
            txt杯數4.setText(杯數4+"");

        }
    };

    private TextWatcher txt杯數4_TextChanged = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            計算總價();

        }
    };


    private View.OnClickListener btn送出訂購單_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

        }
        //  計算總價();
    };


    public void 計算總價() {
        售價1=Double.parseDouble(lbl售價1.getText().toString());
        售價2=Double.parseDouble(lbl售價2.getText().toString());
        售價3=Double.parseDouble(lbl售價3.getText().toString());
        售價4=Double.parseDouble(lbl售價4.getText().toString());


        品項1總價=售價1*杯數1;
        品項2總價=售價2*杯數2;
        品項3總價=售價3*杯數3;
        品項4總價=售價4*杯數4;

        lbl杯數1總價.setText(品項1總價 + "");
        lbl杯數2總價.setText(品項2總價 + "");
        lbl杯數3總價.setText(品項3總價 + "");
        lbl杯數4總價.setText(品項4總價 + "");

        //總杯數=杯數1+杯數2+杯數3+杯數4;
        總價=品項1總價+品項2總價+品項3總價+品項4總價;
        lbl總價.setText(總價+"");


    }


    private void Initial() {
        lbl杯數1總價 = findViewById(R.id.lbl杯數1總價);

        btn杯數1減 = findViewById(R.id.btn杯數1減);
        btn杯數1減.setOnClickListener(btn杯數1減_click);
        btn杯數1加 = findViewById(R.id.btn杯數1加);
        btn杯數1加.setOnClickListener(btn杯數1加_click);

        txt杯數1 = findViewById(R.id.txt杯數1);
        txt杯數1.addTextChangedListener(txt杯數1_TextChanged);


        lbl售價1 = findViewById(R.id.lbl售價1);
        lbl售價1.setText("35");                                   //當
//----------------------------------------------------------------------
        lbl杯數2總價 = findViewById(R.id.lbl杯數2總價);

        btn杯數2減 = findViewById(R.id.btn杯數2減);
        btn杯數2減.setOnClickListener(btn杯數2減_click);
        btn杯數2加 = findViewById(R.id.btn杯數2加);
        btn杯數2加.setOnClickListener(btn杯數2加_click);

        txt杯數2 = findViewById(R.id.txt杯數2);
        txt杯數2.addTextChangedListener(txt杯數2_TextChanged);

        lbl售價2 = findViewById(R.id.lbl售價2);
        lbl售價2.setText("45");
//---------------------------------------------------------------------
        lbl杯數3總價 = findViewById(R.id.lbl杯數3總價);

        btn杯數3減 = findViewById(R.id.btn杯數3減);
        btn杯數3減.setOnClickListener(btn杯數3減_click);
        btn杯數3加 = findViewById(R.id.btn杯數3加);
        btn杯數3加.setOnClickListener(btn杯數3加_click);

        txt杯數3 = findViewById(R.id.txt杯數3);
        txt杯數3.addTextChangedListener(txt杯數3_TextChanged);

        lbl售價3=findViewById(R.id.lbl售價3);
        lbl售價3.setText("25");
//----------------------------------------------------------------------
        lbl杯數4總價 = findViewById(R.id.lbl杯數4總價);
        btn杯數4減 = findViewById(R.id.btn杯數4減);
        btn杯數4減.setOnClickListener(btn杯數4減_click);
        btn杯數4加 = findViewById(R.id.btn杯數4加);
        btn杯數4加.setOnClickListener(btn杯數4加_click);

        txt杯數4 = findViewById(R.id.txt杯數4);
        txt杯數4.addTextChangedListener(txt杯數4_TextChanged);

        lbl售價4=findViewById(R.id.lbl售價4);
        lbl售價4.setText("20");
        
        btn送出訂購單 = findViewById(R.id.btn送出訂購單);
        btn送出訂購單.setOnClickListener(btn送出訂購單_click);

        lbl總價 = findViewById(R.id.lbl總價);



    }

    Button btn杯數1減;
    Button btn杯數1加;
    EditText txt杯數1;
    TextView lbl杯數1總價;
    TextView lbl售價1;

    Button btn杯數2減;
    Button btn杯數2加;
    EditText txt杯數2;
    TextView lbl杯數2總價;
    TextView lbl售價2;

    Button btn杯數3減;
    Button btn杯數3加;
    EditText txt杯數3;
    TextView lbl杯數3總價;
    TextView lbl售價3;

    Button btn杯數4減;
    Button btn杯數4加;
    EditText txt杯數4;
    TextView lbl杯數4總價;
    TextView lbl售價4;


    Button btn送出訂購單;
    TextView lbl總價;
}
